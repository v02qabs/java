dalvikvm -cp /data/data/com.termux/file/usr/bin/filelength.jar filelength $@
