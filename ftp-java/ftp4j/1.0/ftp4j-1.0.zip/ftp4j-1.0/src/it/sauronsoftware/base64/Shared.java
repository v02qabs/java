package it.sauronsoftware.base64;

/**
 * Package related utilities.
 * 
 * @author Carlo Pelliccia
 */
class Shared {

	static String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

	static char pad = '=';

}